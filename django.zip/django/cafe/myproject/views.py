from django.shortcuts import render, redirect
from django.contrib import messages
from .models import TableBooking, Category, MenuItem
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import timedelta, datetime

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        date_str = request.POST.get('date')
        time_str = request.POST.get('time')
        end_time_str = request.POST.get('end_time')
        guests = request.POST.get('guests')
        message = request.POST.get('message')
        
        try:
            # Проверяем корректность даты
            if not date_str:
                raise ValidationError("❌ Пожалуйста, выберите дату")
            
            date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
            time_obj = datetime.strptime(time_str, '%H:%M').time()
            end_time_obj = datetime.strptime(end_time_str, '%H:%M').time()
            
            # Проверяем, не переходит ли время на следующий день
            if time_obj > end_time_obj:
                messages.error(
                    request, 
                    '❌ Бронирование не может переходить на следующий день. '
                    'Пожалуйста, выберите время окончания позже времени начала.'
                )
                return redirect('contact')
            
            # Рассчитываем продолжительность
            start_datetime = datetime.combine(datetime.today(), time_obj)
            end_datetime = datetime.combine(datetime.today(), end_time_obj)
            duration_timedelta = end_datetime - start_datetime
            
            duration_minutes = int(duration_timedelta.total_seconds() / 60)
            
            if duration_minutes <= 0:
                messages.error(request, '❌ Время окончания должно быть позже времени начала')
                return redirect('contact')
            
            # Дополнительная проверка на сервере (дублирующая модель)
            day_of_week = date_obj.weekday()
            
            if day_of_week <= 4:  # Пн-Пт
                opening_time = datetime.strptime('08:00', '%H:%M').time()
                closing_time = datetime.strptime('20:00', '%H:%M').time()
                day_type = "Пн-Пт"
            else:  # Сб-Вс
                opening_time = datetime.strptime('09:00', '%H:%M').time()
                closing_time = datetime.strptime('21:00', '%H:%M').time()
                day_type = "Сб-Вс"
            
            if time_obj < opening_time:
                messages.error(
                    request, 
                    f'❌ В {day_type} кофейня открывается в {opening_time.strftime("%H:%M")}. '
                    f'Пожалуйста, выберите время после {opening_time.strftime("%H:%M")}'
                )
                return redirect('contact')
            
            if end_time_obj > closing_time:
                messages.error(
                    request, 
                    f'❌ В {day_type} кофейня закрывается в {closing_time.strftime("%H:%M")}. '
                    f'Бронирование должно закончиться до {closing_time.strftime("%H:%M")}'
                )
                return redirect('contact')
            
            # Создаем бронирование
            booking = TableBooking(
                name=name,
                phone=phone,
                email=email if email else None,
                date=date_obj,
                time=time_obj,
                duration=duration_minutes,
                guests=guests,
                message=message
            )
            
            booking.full_clean()  # Это вызовет clean() метод с проверкой времени работы
            booking.save()
            
            messages.success(
                request, 
                f'✅ Столик успешно забронирован на имя {name}!\n'
                f'📅 Дата: {date_str}\n'
                f'🕐 Время: {time_str}-{booking.end_time.strftime("%H:%M")}\n'
                f'👥 Гостей: {guests}\n'
                f'📞 Мы вам перезвоним для подтверждения.'
            )
            return redirect('contact')
            
        except ValidationError as e:
            for error in e.messages:
                messages.error(request, error)
            return redirect('contact')
        except ValueError as e:
            messages.error(request, '❌ Ошибка в формате даты или времени')
            return redirect('contact')
        except Exception as e:
            messages.error(request, f'❌ Произошла ошибка: {str(e)}')
            return redirect('contact')
    
    today = timezone.now().date()
    existing_bookings = TableBooking.objects.filter(date__gte=today).order_by('date', 'time')
    
    return render(request, 'cafe/contact.html', {
        'existing_bookings': existing_bookings
    })


def index(request):
    return render(request, 'cafe/index.html')


def about(request):
    return render(request, 'cafe/about.html')


def services(request):
    categories = Category.objects.filter(is_active=True).prefetch_related('menuitem_set')
    menu_items = MenuItem.objects.filter(is_available=True).select_related('category')
    
    menu_by_category = {}
    for category in categories:
        menu_by_category[category] = menu_items.filter(category=category)
    
    return render(request, 'cafe/services.html', {
        'menu_by_category': menu_by_category
    })
    

def promotions(request):
    return render(request, 'cafe/promotions.html')