from django.contrib import admin
from .models import TableBooking, Category, MenuItem

@admin.register(TableBooking)
class TableBookingAdmin(admin.ModelAdmin):
    list_display = ['name', 'phone', 'date', 'time', 'guests', 'created_at']
    list_filter = ['date', 'created_at']
    search_fields = ['name', 'phone']


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['get_category_type_display', 'order', 'is_active']
    list_editable = ['order', 'is_active']
    list_filter = ['category_type', 'is_active']
    
    def get_category_type_display(self, obj):
        return obj.get_category_type_display()
    get_category_type_display.short_description = 'Категория'

    

@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'get_size', 'is_new', 'is_seasonal', 'is_available']
    list_editable = ['price', 'is_new', 'is_seasonal', 'is_available']
    list_filter = ['category', 'is_new', 'is_seasonal', 'is_available']
    search_fields = ['name', 'description']
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('category', 'name', 'description', 'price')
        }),
        ('Размер', {
            'fields': ('volume', 'portion')
        }),
        ('Статусы', {
            'fields': ('is_new', 'is_seasonal', 'available_until')
        }),
        ('Дополнительно', {
            'fields': ('is_available', 'order')
        }),
    )
    
    def get_size(self, obj):
        return obj.size_display
    get_size.short_description = 'Размер'