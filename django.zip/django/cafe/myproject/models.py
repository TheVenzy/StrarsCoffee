from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import timedelta, datetime

class TableBooking(models.Model):
    name = models.CharField(max_length=100, verbose_name="Имя")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    email = models.EmailField(verbose_name="Email", blank=True, null=True)
    date = models.DateField(verbose_name="Дата")
    time = models.TimeField(verbose_name="Время начала")
    duration = models.IntegerField(verbose_name="Продолжительность (минуты)", default=60)
    guests = models.IntegerField(verbose_name="Количество гостей")
    message = models.TextField(verbose_name="Дополнительные пожелания", blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    
    def __str__(self):
        return f"{self.name} - {self.date} {self.time}"
    
    @property
    def end_time(self):
        start_datetime = timezone.datetime.combine(self.date, self.time)
        end_datetime = start_datetime + timedelta(minutes=self.duration)
        return end_datetime.time()
    
    def clean(self):
        if self.date < timezone.now().date():
            raise ValidationError("Нельзя забронировать столик на прошедшую дату")
        
        if self.date == timezone.now().date() and self.time < timezone.now().time():
            raise ValidationError("Нельзя забронировать столик на прошедшее время")
        
        # Проверка времени работы кофейни
        self.check_opening_hours()
        
        self.check_time_overlap()
    
    def check_opening_hours(self):
        """Проверка времени работы кофейни"""
        day_of_week = self.date.weekday()  # 0-пн, 1-вт, ..., 5-сб, 6-вс
        
        # Определяем время работы для дня недели
        if day_of_week <= 4:  # Пн-Пт
            opening_time = datetime.strptime('08:00', '%H:%M').time()
            closing_time = datetime.strptime('20:00', '%H:%M').time()
            day_type = "Пн-Пт"
        else:  # Сб-Вс
            opening_time = datetime.strptime('09:00', '%H:%M').time()
            closing_time = datetime.strptime('21:00', '%H:%M').time()
            day_type = "Сб-Вс"
        
        # Проверяем время начала
        if self.time < opening_time:
            raise ValidationError(
                f"❌ В {day_type} кофейня открывается в {opening_time.strftime('%H:%M')}. "
                f"Выберите время после {opening_time.strftime('%H:%M')}"
            )
        
        # Вычисляем время окончания брони
        start_datetime = datetime.combine(self.date, self.time)
        end_datetime = start_datetime + timedelta(minutes=self.duration)
        end_time = end_datetime.time()
        
        # Если бронирование переходит на следующий день - это запрещено
        if end_datetime.date() > self.date:
            raise ValidationError(
                f"❌ Бронирование не может переходить на следующий день. "
                f"Кофейня закрывается в {closing_time.strftime('%H:%M')}"
            )
        
        # Проверяем время окончания
        if end_time > closing_time:
            raise ValidationError(
                f"❌ В {day_type} кофейня закрывается в {closing_time.strftime('%H:%M')}. "
                f"Бронирование должно закончиться до {closing_time.strftime('%H:%M')}"
            )
    
    def check_time_overlap(self):
        start_datetime = timezone.datetime.combine(self.date, self.time)
        end_datetime = start_datetime + timedelta(minutes=self.duration)
        
        existing_bookings = TableBooking.objects.filter(date=self.date).exclude(pk=self.pk)
        
        for booking in existing_bookings:
            existing_start = timezone.datetime.combine(booking.date, booking.time)
            existing_end = existing_start + timedelta(minutes=booking.duration)
            
            if (start_datetime < existing_end and end_datetime > existing_start):
                raise ValidationError(
                    f"❌ Время пересекается с существующей броньью: "
                    f"{booking.time.strftime('%H:%M')}-{booking.end_time.strftime('%H:%M')}"
                )
    
    class Meta:
        verbose_name = "Бронь столика"
        verbose_name_plural = "Брони столиков"
        ordering = ['-created_at']


class Category(models.Model):
    CATEGORY_TYPES = [
        ('coffee', '☕️ Кофе'),
        ('tea', '🍵 Чай'),
        ('desserts', '🍰 Десерты'),
        ('seasonal', '🍂 Сезонные предложения'),
    ]
    
    category_type = models.CharField(
        max_length=20, 
        choices=CATEGORY_TYPES, 
        default='coffee',
        verbose_name="Тип категории"
    )
    order = models.IntegerField(default=0, verbose_name="Порядок отображения")
    is_active = models.BooleanField(default=True, verbose_name="Активна")
    
    def __str__(self):
        return self.get_category_type_display()
    
    class Meta:
        verbose_name = "Категория меню"
        verbose_name_plural = "Категории меню"
        ordering = ['order']


class MenuItem(models.Model):
    VOLUME_CHOICES = [
        ('30 мл', '30 мл'),
        ('180 мл', '180 мл'),
        ('250 мл', '250 мл'),
        ('350 мл', '350 мл'),
        ('450 мл', '450 мл'),
        ('500 мл', '500 мл'),
    ]
    
    PORTION_CHOICES = [
        ('80 г', '80 г'),
        ('120 г', '120 г'),
        ('150 г', '150 г'),
        ('200 г', '200 г'),
        ('3 шт', '3 шт'),
        ('6 шт', '6 шт'),
    ]
    
    category = models.ForeignKey(Category, on_delete=models.CASCADE, verbose_name="Категория")
    name = models.CharField(max_length=200, verbose_name="Название")
    description = models.TextField(verbose_name="Описание", blank=True)
    price = models.DecimalField(max_digits=8, decimal_places=2, verbose_name="Цена")
    
    # Для напитков
    volume = models.CharField(
        max_length=50, 
        choices=VOLUME_CHOICES, 
        blank=True, 
        verbose_name="Объем"
    )
    
    # Для еды/десертов
    portion = models.CharField(
        max_length=50, 
        choices=PORTION_CHOICES, 
        blank=True, 
        verbose_name="Порция"
    )
    
    # Новинка в любой категории
    is_new = models.BooleanField(default=False, verbose_name="Новинка")
    
    # Для сезонных предложений
    is_seasonal = models.BooleanField(default=False, verbose_name="Сезонное предложение")
    available_until = models.DateField(blank=True, null=True, verbose_name="Доступно до")
    
    is_available = models.BooleanField(default=True, verbose_name="Доступно")
    order = models.IntegerField(default=0, verbose_name="Порядок отображения")
    
    def __str__(self):
        return f"{self.name} - {self.price}₽"
    
    @property
    def size_display(self):
        if self.volume:
            return self.volume
        elif self.portion:
            return self.portion
        return ""
    
    class Meta:
        verbose_name = "Позиция меню"
        verbose_name_plural = "Позиции меню"
        ordering = ['category__order', 'order']